# mars2d
 Mars2D ( MarsGIS for Leaflet ) 地图平台核心SDK类库



## Mars2D介绍
 Mars2D地图平台软件（曾用名 MarsGIS for Leaflet ） 是[火星科技](http://www.marsgis.cn/)研发的一个Web地图开发平台系统，是火星科技团队成员多年GIS开发和Leaflet使用的技术沉淀。基于Leaflet和现代Web技术栈全新构建， 集成了领先的开源地图库、可视化库，提供了全新的大数据可视化、实时流数据可视化功能，通过本产品可快速实现浏览器和移动端上美观、流畅的地图呈现与空间分析。

  
