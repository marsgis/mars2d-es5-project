#jquery 
	 jQuery 是一个传统的JavaScript 库。 jQuery 极大地简化了 JavaScript 编程。  

github地址：https://github.com/jquery/jquery
官方网站：https://jquery.com/

本地版本： 2.1.4 （第2版最终版）
 

基于jquery的插件放在该目录
