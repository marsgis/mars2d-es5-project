#layer web弹层组件


github地址：https://github.com/sentsin/layer/
官方网站：http://layer.layui.com/


本地版本：3.5.1 
 
