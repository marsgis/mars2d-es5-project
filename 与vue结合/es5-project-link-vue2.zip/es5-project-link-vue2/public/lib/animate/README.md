#animate 跨浏览器的CSS3动画库

github地址：https://github.com/daneden/animate.css

本地版本： 3.5.2
更新日期：

介绍：
	要在你的站点中使用 animate.css，只需将样式文件放入你的页面的 <head> 中，然后将 animated 样式添加到一个元素上，
	并且加上任意一个动画的名字，就这样，你就得到了一个 CSS 动画的元素！
	当你将 animate.css 与 jQuery 一起使用或者添加你自己的 CSS 规则时， 你可以用 animate.css 做一大堆其他的事，
	使用 jQuery 动态添加动画：$('#yourElement').addClass('animated bounceOutLeft');

